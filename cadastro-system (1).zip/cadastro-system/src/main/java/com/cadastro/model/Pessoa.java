package com.cadastro.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Objects;

/**
 * Entidade principal do sistema.
 * Implementa Serializable para persistência em arquivo.
 */
public class Pessoa implements Serializable {

    private static final long serialVersionUID = 1L;
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy");

    private final int    id;
    private String       nome;
    private String       cpf;
    private String       email;
    private String       telefone;
    private LocalDate    dataNascimento;

    public Pessoa(int id, String nome, String cpf, String email,
                  String telefone, LocalDate dataNascimento) {
        this.id             = id;
        this.nome           = nome;
        this.cpf            = cpf;
        this.email          = email;
        this.telefone       = telefone;
        this.dataNascimento = dataNascimento;
    }

    // ── Getters ───────────────────────────────────────────────────────────────

    public int       getId()             { return id; }
    public String    getNome()           { return nome; }
    public String    getCpf()            { return cpf; }
    public String    getEmail()          { return email; }
    public String    getTelefone()       { return telefone; }
    public LocalDate getDataNascimento() { return dataNascimento; }

    public int getIdade() {
        return Period.between(dataNascimento, LocalDate.now()).getYears();
    }

    // ── Setters (usados na atualização) ───────────────────────────────────────

    public void setNome(String nome)                     { this.nome = nome; }
    public void setEmail(String email)                   { this.email = email; }
    public void setTelefone(String telefone)             { this.telefone = telefone; }
    public void setDataNascimento(LocalDate dataNasc)    { this.dataNascimento = dataNasc; }

    // ── Display ───────────────────────────────────────────────────────────────

    public String toResumido() {
        return String.format("  [%04d] %-30s CPF: %s", id, nome, cpfFormatado());
    }

    public String toDetalhado() {
        return String.format(
            "┌─────────────────────────────────────────┐%n" +
            "│  ID          : %-26d│%n" +
            "│  Nome        : %-26s│%n" +
            "│  CPF         : %-26s│%n" +
            "│  E-mail      : %-26s│%n" +
            "│  Telefone    : %-26s│%n" +
            "│  Nascimento  : %-8s  (%d anos)%13s│%n" +
            "└─────────────────────────────────────────┘",
            id, truncar(nome, 26), cpfFormatado(),
            truncar(email, 26), telefone,
            dataNascimento.format(FMT), getIdade(), ""
        );
    }

    private String cpfFormatado() {
        if (cpf.length() == 11)
            return cpf.substring(0,3)+"."+cpf.substring(3,6)+"."+cpf.substring(6,9)+"-"+cpf.substring(9);
        return cpf;
    }

    private String truncar(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 1) + "…";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Pessoa p)) return false;
        return id == p.id;
    }

    @Override
    public int hashCode() { return Objects.hash(id); }

    @Override
    public String toString() { return toResumido(); }
}
