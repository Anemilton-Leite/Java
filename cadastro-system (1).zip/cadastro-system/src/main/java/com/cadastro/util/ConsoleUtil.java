package com.cadastro.util;

import java.util.Scanner;

/**
 * Utilitários de console: leitura segura, formatação, separadores.
 */
public final class ConsoleUtil {

    public static final String RESET  = "\u001B[0m";
    public static final String BOLD   = "\u001B[1m";
    public static final String RED    = "\u001B[31m";
    public static final String GREEN  = "\u001B[32m";
    public static final String YELLOW = "\u001B[33m";
    public static final String CYAN   = "\u001B[36m";
    public static final String DIM    = "\u001B[2m";

    private ConsoleUtil() {}

    /** Lê uma linha inteira, nunca retorna null. Retorna "" se scanner fechar. */
    public static String lerLinha(Scanner sc, String prompt) {
        System.out.print(CYAN + prompt + RESET);
        try {
            if (sc.hasNextLine()) return sc.nextLine();
        } catch (Exception e) {
            System.err.println(RED + "[ERRO] Falha na leitura: " + e.getMessage() + RESET);
        }
        return "";
    }

    /**
     * Lê uma linha, mas retorna o {@code valorPadrao} se o usuário pressionar Enter vazio.
     * Usado para campos opcionais na atualização.
     */
    public static String lerLinhaOpcional(Scanner sc, String prompt, String valorPadrao) {
        System.out.print(CYAN + prompt + DIM + " [Enter = manter atual]" + RESET + CYAN + ": " + RESET);
        try {
            String linha = sc.hasNextLine() ? sc.nextLine() : "";
            return linha.isBlank() ? valorPadrao : linha;
        } catch (Exception e) {
            return valorPadrao;
        }
    }

    public static void separador() {
        System.out.println(DIM + "─".repeat(45) + RESET);
    }

    public static void titulo(String texto) {
        System.out.println();
        System.out.println(BOLD + CYAN + "  ══ " + texto + " ══" + RESET);
        separador();
    }

    public static void sucesso(String msg) {
        System.out.println(GREEN + "  ✔ " + msg + RESET);
    }

    public static void erro(String msg) {
        System.out.println(RED + "  ✘ " + msg + RESET);
    }

    public static void aviso(String msg) {
        System.out.println(YELLOW + "  ⚠ " + msg + RESET);
    }

    public static void info(String msg) {
        System.out.println(DIM + "  · " + msg + RESET);
    }

    /** Aguarda Enter para continuar. */
    public static void aguardarEnter(Scanner sc) {
        System.out.print(DIM + "\n  [Pressione Enter para continuar]" + RESET);
        try { if (sc.hasNextLine()) sc.nextLine(); } catch (Exception ignored) {}
    }

    /** Solicita confirmação S/N. Retorna false em qualquer entrada inválida. */
    public static boolean confirmar(Scanner sc, String pergunta) {
        System.out.print(YELLOW + "  " + pergunta + " [S/N]: " + RESET);
        try {
            String resp = sc.hasNextLine() ? sc.nextLine().trim().toUpperCase() : "N";
            return resp.equals("S") || resp.equals("SIM");
        } catch (Exception e) {
            return false;
        }
    }
}
