package com.cadastro.validator;

import com.cadastro.exception.ValidacaoException;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.regex.Pattern;

/**
 * Centraliza todas as validações de entrada do sistema.
 * Cada método lança {@link ValidacaoException} em caso de falha.
 */
public final class InputValidator {

    private InputValidator() {}

    private static final Pattern EMAIL_PATTERN =
        Pattern.compile("^[\\w.+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}$");

    private static final Pattern TELEFONE_PATTERN =
        Pattern.compile("^\\(?\\d{2}\\)?[\\s-]?\\d{4,5}[\\s-]?\\d{4}$");

    private static final Pattern NOME_PATTERN =
        Pattern.compile("^[\\p{L}\\s]{2,100}$");

    private static final DateTimeFormatter DATE_FMT =
        DateTimeFormatter.ofPattern("dd/MM/yyyy");

    // ── Nome ─────────────────────────────────────────────────────────────────

    public static String validarNome(String nome) {
        if (nome == null || nome.isBlank())
            throw new ValidacaoException("nome", "não pode ser vazio.");
        nome = nome.trim();
        if (!NOME_PATTERN.matcher(nome).matches())
            throw new ValidacaoException("nome",
                "deve ter entre 2-100 caracteres e conter apenas letras e espaços.");
        return nome;
    }

    // ── CPF ──────────────────────────────────────────────────────────────────

    public static String validarCpf(String cpf) {
        if (cpf == null || cpf.isBlank())
            throw new ValidacaoException("cpf", "não pode ser vazio.");

        cpf = cpf.replaceAll("[.\\-]", "").trim();

        if (!cpf.matches("\\d{11}"))
            throw new ValidacaoException("cpf",
                "deve conter exatamente 11 dígitos numéricos (ex: 123.456.789-09).");

        if (cpf.chars().distinct().count() == 1)
            throw new ValidacaoException("cpf", "sequência de dígitos iguais não é válida.");

        if (!digitosValidos(cpf))
            throw new ValidacaoException("cpf", "dígitos verificadores inválidos.");

        return cpf;
    }

    private static boolean digitosValidos(String cpf) {
        int[] d = cpf.chars().map(c -> c - '0').toArray();

        int s1 = 0;
        for (int i = 0; i < 9; i++) s1 += d[i] * (10 - i);
        int r1 = (s1 * 10) % 11;
        if (r1 == 10 || r1 == 11) r1 = 0;
        if (r1 != d[9]) return false;

        int s2 = 0;
        for (int i = 0; i < 10; i++) s2 += d[i] * (11 - i);
        int r2 = (s2 * 10) % 11;
        if (r2 == 10 || r2 == 11) r2 = 0;
        return r2 == d[10];
    }

    // ── E-mail ────────────────────────────────────────────────────────────────

    public static String validarEmail(String email) {
        if (email == null || email.isBlank())
            throw new ValidacaoException("email", "não pode ser vazio.");
        email = email.trim().toLowerCase();
        if (!EMAIL_PATTERN.matcher(email).matches())
            throw new ValidacaoException("email",
                "formato inválido (ex: usuario@dominio.com).");
        if (email.length() > 254)
            throw new ValidacaoException("email", "não pode ultrapassar 254 caracteres.");
        return email;
    }

    // ── Telefone ──────────────────────────────────────────────────────────────

    public static String validarTelefone(String telefone) {
        if (telefone == null || telefone.isBlank())
            throw new ValidacaoException("telefone", "não pode ser vazio.");
        telefone = telefone.trim();
        if (!TELEFONE_PATTERN.matcher(telefone).matches())
            throw new ValidacaoException("telefone",
                "formato inválido (ex: (85) 98765-4321 ou (85) 3221-1234).");
        return telefone;
    }

    // ── Data de Nascimento ────────────────────────────────────────────────────

    public static LocalDate validarDataNascimento(String dataStr) {
        if (dataStr == null || dataStr.isBlank())
            throw new ValidacaoException("dataNascimento", "não pode ser vazio.");
        dataStr = dataStr.trim();

        LocalDate data;
        try {
            data = LocalDate.parse(dataStr, DATE_FMT);
        } catch (DateTimeParseException e) {
            throw new ValidacaoException("dataNascimento",
                "formato inválido — use DD/MM/AAAA (ex: 15/03/1990).");
        }

        if (data.isAfter(LocalDate.now()))
            throw new ValidacaoException("dataNascimento",
                "data de nascimento não pode ser no futuro.");

        int idade = LocalDate.now().getYear() - data.getYear();
        if (idade > 150)
            throw new ValidacaoException("dataNascimento",
                "data de nascimento implica idade maior que 150 anos.");

        return data;
    }

    // ── Inteiro de menu ───────────────────────────────────────────────────────

    /**
     * Tenta converter {@code input} para inteiro dentro de [min, max].
     * Retorna {@code -1} em caso de entrada inválida (sem lançar exceção),
     * permitindo que o menu mostre uma mensagem amigável e repita.
     */
    public static int parseOpcao(String input, int min, int max) {
        try {
            int val = Integer.parseInt(input.trim());
            if (val >= min && val <= max) return val;
        } catch (NumberFormatException ignored) {}
        return -1;
    }

    /**
     * Converte para int positivo (ID). Retorna -1 se inválido.
     */
    public static int parseId(String input) {
        try {
            int val = Integer.parseInt(input.trim());
            return val > 0 ? val : -1;
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}
