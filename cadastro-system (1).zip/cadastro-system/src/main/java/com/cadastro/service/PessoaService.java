package com.cadastro.service;

import com.cadastro.exception.CadastroException;
import com.cadastro.model.Pessoa;
import com.cadastro.repository.PessoaRepository;
import com.cadastro.validator.InputValidator;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

/**
 * Serviço com regras de negócio do sistema de cadastro.
 */
public class PessoaService {

    private final PessoaRepository repo;

    public PessoaService(PessoaRepository repo) {
        this.repo = repo;
    }

    // ── Criar ─────────────────────────────────────────────────────────────────

    public Pessoa cadastrar(String nome, String cpf, String email,
                            String telefone, String dataNascStr) {

        // Validações de formato (lança ValidacaoException se inválido)
        String       nomeVal  = InputValidator.validarNome(nome);
        String       cpfVal   = InputValidator.validarCpf(cpf);
        String       emailVal = InputValidator.validarEmail(email);
        String       telVal   = InputValidator.validarTelefone(telefone);
        LocalDate    dataNasc = InputValidator.validarDataNascimento(dataNascStr);

        // Unicidade de CPF
        if (repo.buscarPorCpf(cpfVal).isPresent())
            throw new CadastroException("CPF '" + cpfVal + "' já está cadastrado no sistema.");

        // Unicidade de e-mail
        if (repo.buscarPorEmail(emailVal).isPresent())
            throw new CadastroException("E-mail '" + emailVal + "' já está em uso.");

        Pessoa p = new Pessoa(repo.proximoId(), nomeVal, cpfVal, emailVal, telVal, dataNasc);
        return repo.salvar(p);
    }

    // ── Ler ───────────────────────────────────────────────────────────────────

    public Pessoa buscarPorId(int id) {
        return repo.buscarPorId(id)
            .orElseThrow(() -> new CadastroException("Nenhum cadastro encontrado com ID " + id + "."));
    }

    public List<Pessoa> buscarPorNome(String fragmento) {
        List<Pessoa> resultado = repo.buscarPorNome(fragmento);
        if (resultado.isEmpty())
            throw new CadastroException("Nenhum cadastro encontrado com nome contendo '" + fragmento + "'.");
        return resultado;
    }

    public Optional<Pessoa> buscarPorEmail(String email) {
        return repo.buscarPorEmail(email);
    }

    public List<Pessoa> listarTodos() {
        return repo.listarTodos();
    }

    public int total() {
        return repo.total();
    }

    // ── Atualizar ─────────────────────────────────────────────────────────────

    public Pessoa atualizar(int id, String novoNome, String novoEmail,
                            String novoTelefone, String novaDataStr) {

        Pessoa p = buscarPorId(id);

        if (novoNome != null && !novoNome.isBlank())
            p.setNome(InputValidator.validarNome(novoNome));

        if (novoEmail != null && !novoEmail.isBlank()) {
            String emailVal = InputValidator.validarEmail(novoEmail);
            Optional<Pessoa> outro = repo.buscarPorEmail(emailVal);
            if (outro.isPresent() && outro.get().getId() != id)
                throw new CadastroException("E-mail '" + emailVal + "' já está em uso por outro cadastro.");
            p.setEmail(emailVal);
        }

        if (novoTelefone != null && !novoTelefone.isBlank())
            p.setTelefone(InputValidator.validarTelefone(novoTelefone));

        if (novaDataStr != null && !novaDataStr.isBlank())
            p.setDataNascimento(InputValidator.validarDataNascimento(novaDataStr));

        return repo.salvar(p);
    }

    // ── Excluir ───────────────────────────────────────────────────────────────

    public void excluir(int id) {
        // Garante que existe antes de tentar excluir
        buscarPorId(id);
        repo.excluir(id);
    }
}
