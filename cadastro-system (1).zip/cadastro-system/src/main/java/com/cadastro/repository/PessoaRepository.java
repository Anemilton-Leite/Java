package com.cadastro.repository;

import com.cadastro.model.Pessoa;

import java.io.*;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

/**
 * Repositório de pessoas: armazenamento em memória com
 * persistência opcional em arquivo via serialização Java.
 */
public class PessoaRepository {

    private static final String ARQUIVO = "cadastros.dat";

    private final Map<Integer, Pessoa> dados = new LinkedHashMap<>();
    private final AtomicInteger        proximoId;

    public PessoaRepository() {
        Map<Integer, Pessoa> carregados = carregar();
        dados.putAll(carregados);
        int maxId = carregados.keySet().stream().mapToInt(i -> i).max().orElse(0);
        proximoId = new AtomicInteger(maxId + 1);
    }

    // ── CRUD ──────────────────────────────────────────────────────────────────

    public Pessoa salvar(Pessoa p) {
        dados.put(p.getId(), p);
        persistir();
        return p;
    }

    public int proximoId() {
        return proximoId.getAndIncrement();
    }

    public Optional<Pessoa> buscarPorId(int id) {
        return Optional.ofNullable(dados.get(id));
    }

    public List<Pessoa> buscarPorNome(String fragmento) {
        String lower = fragmento.toLowerCase();
        return dados.values().stream()
            .filter(p -> p.getNome().toLowerCase().contains(lower))
            .collect(Collectors.toList());
    }

    public Optional<Pessoa> buscarPorEmail(String email) {
        return dados.values().stream()
            .filter(p -> p.getEmail().equalsIgnoreCase(email))
            .findFirst();
    }

    public Optional<Pessoa> buscarPorCpf(String cpf) {
        return dados.values().stream()
            .filter(p -> p.getCpf().equals(cpf))
            .findFirst();
    }

    public List<Pessoa> listarTodos() {
        return new ArrayList<>(dados.values());
    }

    public boolean excluir(int id) {
        boolean removido = dados.remove(id) != null;
        if (removido) persistir();
        return removido;
    }

    public int total() {
        return dados.size();
    }

    // ── Persistência ──────────────────────────────────────────────────────────

    @SuppressWarnings("unchecked")
    private Map<Integer, Pessoa> carregar() {
        File f = new File(ARQUIVO);
        if (!f.exists()) return new LinkedHashMap<>();
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
            return (Map<Integer, Pessoa>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("[AVISO] Não foi possível carregar arquivo de dados: " + e.getMessage());
            return new LinkedHashMap<>();
        }
    }

    private void persistir() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARQUIVO))) {
            oos.writeObject(dados);
        } catch (IOException e) {
            System.err.println("[AVISO] Não foi possível salvar arquivo de dados: " + e.getMessage());
        }
    }
}
