package com.cadastro.exception;

/**
 * Exceção lançada quando um campo falha na validação de formato/regra.
 */
public class ValidacaoException extends RuntimeException {

    private final String campo;

    public ValidacaoException(String campo, String motivo) {
        super(String.format("Campo '%s': %s", campo, motivo));
        this.campo = campo;
    }

    public String getCampo() { return campo; }
}
