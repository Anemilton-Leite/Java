package com.cadastro.exception;

/**
 * Exceção de regra de negócio (ex: CPF duplicado, ID não encontrado).
 */
public class CadastroException extends RuntimeException {
    public CadastroException(String message) {
        super(message);
    }
}
