package com.cadastro.ui;

import com.cadastro.exception.CadastroException;
import com.cadastro.exception.ValidacaoException;
import com.cadastro.model.Pessoa;
import com.cadastro.service.PessoaService;
import com.cadastro.util.ConsoleUtil;
import com.cadastro.validator.InputValidator;

import java.util.List;
import java.util.Scanner;

import static com.cadastro.util.ConsoleUtil.*;

/**
 * Camada de apresentação: menus interativos com proteção total contra entradas inválidas.
 */
public class Menu {

    private final PessoaService service;
    private final Scanner       sc;
    private       boolean       rodando = true;

    public Menu(PessoaService service, Scanner sc) {
        this.service = service;
        this.sc      = sc;
    }

    // ── Loop principal ────────────────────────────────────────────────────────

    public void iniciar() {
        exibirBanner();
        while (rodando) {
            exibirMenuPrincipal();
            String input = lerLinha(sc, "  Opção: ");
            int opcao = InputValidator.parseOpcao(input, 0, 6);
            tratarOpcaoPrincipal(opcao);
        }
    }

    private void tratarOpcaoPrincipal(int opcao) {
        switch (opcao) {
            case 1 -> fluxoCadastrar();
            case 2 -> fluxoBuscar();
            case 3 -> fluxoListar();
            case 4 -> fluxoAtualizar();
            case 5 -> fluxoExcluir();
            case 6 -> fluxoEstatisticas();
            case 0 -> sair();
            default -> erro("Opção inválida. Digite um número entre 0 e 6.");
        }
    }

    // ── Banner ────────────────────────────────────────────────────────────────

    private void exibirBanner() {
        System.out.println();
        System.out.println(BOLD + CYAN +
            "  ╔══════════════════════════════════════════╗\n" +
            "  ║    SISTEMA DE GESTÃO DE CADASTROS  v1.0  ║\n" +
            "  ╚══════════════════════════════════════════╝" + RESET);
        info("Dados carregados. Total de cadastros: " + service.total());
    }

    private void exibirMenuPrincipal() {
        System.out.println();
        separador();
        System.out.println(BOLD + "  MENU PRINCIPAL" + RESET);
        separador();
        System.out.println("  1 · Cadastrar pessoa");
        System.out.println("  2 · Buscar pessoa");
        System.out.println("  3 · Listar todos");
        System.out.println("  4 · Atualizar cadastro");
        System.out.println("  5 · Excluir cadastro");
        System.out.println("  6 · Estatísticas");
        System.out.println("  0 · Sair");
        separador();
    }

    // ── 1. CADASTRAR ──────────────────────────────────────────────────────────

    private void fluxoCadastrar() {
        titulo("NOVO CADASTRO");
        try {
            String nome    = lerLinha(sc, "  Nome completo   : ");
            String cpf     = lerLinha(sc, "  CPF             : ");
            String email   = lerLinha(sc, "  E-mail          : ");
            String tel     = lerLinha(sc, "  Telefone        : ");
            String dataNasc = lerLinha(sc, "  Nascimento (DD/MM/AAAA): ");

            Pessoa p = service.cadastrar(nome, cpf, email, tel, dataNasc);
            sucesso("Cadastro realizado com sucesso! ID: " + p.getId());
            System.out.println(p.toDetalhado());

        } catch (ValidacaoException e) {
            erro("Validação: " + e.getMessage());
        } catch (CadastroException e) {
            aviso("Regra de negócio: " + e.getMessage());
        } catch (Exception e) {
            erro("Erro inesperado ao cadastrar: " + e.getMessage());
        }
        aguardarEnter(sc);
    }

    // ── 2. BUSCAR ─────────────────────────────────────────────────────────────

    private void fluxoBuscar() {
        titulo("BUSCAR PESSOA");
        System.out.println("  1 · Por ID");
        System.out.println("  2 · Por nome");
        System.out.println("  3 · Por e-mail");
        System.out.println("  0 · Voltar");
        separador();

        String input = lerLinha(sc, "  Opção: ");
        int opcao = InputValidator.parseOpcao(input, 0, 3);

        switch (opcao) {
            case 1 -> buscarPorId();
            case 2 -> buscarPorNome();
            case 3 -> buscarPorEmail();
            case 0 -> { return; }
            default -> erro("Opção inválida.");
        }
        aguardarEnter(sc);
    }

    private void buscarPorId() {
        String input = lerLinha(sc, "  ID: ");
        int id = InputValidator.parseId(input);
        if (id < 0) { erro("ID inválido. Deve ser um número positivo."); return; }
        try {
            System.out.println(service.buscarPorId(id).toDetalhado());
        } catch (CadastroException e) {
            aviso(e.getMessage());
        }
    }

    private void buscarPorNome() {
        String nome = lerLinha(sc, "  Nome (parcial): ");
        if (nome.isBlank()) { erro("Nome não pode ser vazio."); return; }
        try {
            List<Pessoa> lista = service.buscarPorNome(nome);
            sucesso(lista.size() + " resultado(s) encontrado(s):");
            lista.forEach(p -> System.out.println(p.toResumido()));
        } catch (CadastroException e) {
            aviso(e.getMessage());
        }
    }

    private void buscarPorEmail() {
        String email = lerLinha(sc, "  E-mail: ");
        if (email.isBlank()) { erro("E-mail não pode ser vazio."); return; }
        service.buscarPorEmail(email)
            .ifPresentOrElse(
                p -> System.out.println(p.toDetalhado()),
                ()  -> aviso("Nenhum cadastro encontrado com e-mail '" + email + "'.")
            );
    }

    // ── 3. LISTAR ─────────────────────────────────────────────────────────────

    private void fluxoListar() {
        titulo("TODOS OS CADASTROS");
        List<Pessoa> lista = service.listarTodos();
        if (lista.isEmpty()) {
            aviso("Nenhum cadastro registrado ainda.");
            aguardarEnter(sc);
            return;
        }

        final int PAGE = 10;
        int total = lista.size();
        int pagina = 0;
        int totalPaginas = (int) Math.ceil((double) total / PAGE);

        while (true) {
            int inicio = pagina * PAGE;
            int fim    = Math.min(inicio + PAGE, total);
            System.out.printf("%n  Página %d de %d  (%d cadastros no total)%n",
                pagina + 1, totalPaginas, total);
            separador();
            lista.subList(inicio, fim).forEach(p -> System.out.println(p.toResumido()));
            separador();

            if (totalPaginas == 1) break;

            System.out.println("  [P] Próxima  [A] Anterior  [0] Voltar");
            String nav = lerLinha(sc, "  Navegação: ").toUpperCase();
            if (nav.equals("P") && pagina < totalPaginas - 1) pagina++;
            else if (nav.equals("A") && pagina > 0) pagina--;
            else if (nav.equals("0")) break;
            else aviso("Opção inválida de navegação.");
        }
        aguardarEnter(sc);
    }

    // ── 4. ATUALIZAR ──────────────────────────────────────────────────────────

    private void fluxoAtualizar() {
        titulo("ATUALIZAR CADASTRO");
        String input = lerLinha(sc, "  ID do cadastro a atualizar: ");
        int id = InputValidator.parseId(input);
        if (id < 0) { erro("ID inválido."); aguardarEnter(sc); return; }

        Pessoa atual;
        try {
            atual = service.buscarPorId(id);
        } catch (CadastroException e) {
            aviso(e.getMessage()); aguardarEnter(sc); return;
        }

        System.out.println("\n" + atual.toDetalhado());
        info("Deixe em branco para manter o valor atual.");

        try {
            String novoNome  = lerLinhaOpcional(sc, "  Nome",       atual.getNome());
            String novoEmail = lerLinhaOpcional(sc, "  E-mail",     atual.getEmail());
            String novoTel   = lerLinhaOpcional(sc, "  Telefone",   atual.getTelefone());
            String novaData  = lerLinhaOpcional(sc, "  Nascimento", "");

            Pessoa atualizada = service.atualizar(id, novoNome, novoEmail, novoTel, novaData);
            sucesso("Cadastro atualizado com sucesso!");
            System.out.println(atualizada.toDetalhado());

        } catch (ValidacaoException e) {
            erro("Validação: " + e.getMessage());
        } catch (CadastroException e) {
            aviso("Regra de negócio: " + e.getMessage());
        } catch (Exception e) {
            erro("Erro inesperado: " + e.getMessage());
        }
        aguardarEnter(sc);
    }

    // ── 5. EXCLUIR ────────────────────────────────────────────────────────────

    private void fluxoExcluir() {
        titulo("EXCLUIR CADASTRO");
        String input = lerLinha(sc, "  ID do cadastro a excluir: ");
        int id = InputValidator.parseId(input);
        if (id < 0) { erro("ID inválido."); aguardarEnter(sc); return; }

        try {
            Pessoa p = service.buscarPorId(id);
            System.out.println(p.toDetalhado());

            if (!confirmar(sc, "Deseja realmente excluir este cadastro?")) {
                info("Operação cancelada."); aguardarEnter(sc); return;
            }

            service.excluir(id);
            sucesso("Cadastro ID " + id + " excluído com sucesso.");

        } catch (CadastroException e) {
            aviso(e.getMessage());
        } catch (Exception e) {
            erro("Erro inesperado ao excluir: " + e.getMessage());
        }
        aguardarEnter(sc);
    }

    // ── 6. ESTATÍSTICAS ───────────────────────────────────────────────────────

    private void fluxoEstatisticas() {
        titulo("ESTATÍSTICAS");
        List<Pessoa> todos = service.listarTodos();
        int total = todos.size();

        System.out.printf("  Total de cadastros : %d%n", total);

        if (total > 0) {
            double mediaIdade = todos.stream()
                .mapToInt(Pessoa::getIdade)
                .average()
                .orElse(0);
            int maiorId = todos.stream().mapToInt(Pessoa::getId).max().orElse(0);
            System.out.printf("  Média de idade     : %.1f anos%n", mediaIdade);
            System.out.printf("  Último ID gerado   : %d%n", maiorId);
        }
        aguardarEnter(sc);
    }

    // ── Sair ──────────────────────────────────────────────────────────────────

    private void sair() {
        if (confirmar(sc, "Deseja sair do sistema?")) {
            sucesso("Sistema encerrado. Até logo!");
            rodando = false;
        }
    }
}
