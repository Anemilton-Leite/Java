package com.cadastro;

import com.cadastro.repository.PessoaRepository;
import com.cadastro.service.PessoaService;
import com.cadastro.ui.Menu;

import java.util.Scanner;

/**
 * Ponto de entrada do sistema.
 * Garante que qualquer exceção não tratada nas camadas internas
 * não derrube o programa abruptamente.
 */
public class Main {

    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            PessoaRepository repo    = new PessoaRepository();
            PessoaService    service = new PessoaService(repo);
            Menu             menu    = new Menu(service, sc);

            menu.iniciar();

        } catch (Exception e) {
            // Último nível de proteção: nada deve derrubar a JVM sem mensagem clara.
            System.err.println("\n[ERRO FATAL] O sistema encontrou um problema inesperado:");
            System.err.println("  " + e.getMessage());
            System.err.println("  O programa será encerrado.");
            System.exit(1);
        }
    }
}
